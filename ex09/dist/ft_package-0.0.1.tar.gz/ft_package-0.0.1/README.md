# ft_package

`ft_package` is a simple Python package created as part of the 42 Piscine Python.  
It provides a utility function `count_in_list` that counts how many times an item appears in a list.  
This project demonstrates how to build and distribute a Python package using setuptools.